/**
 * Project 1 - Interactive Image
 * Name: HARMONY SINGH; 10/07/22
 * Comments: This is an image of a phone moving across a belt. If you press the mouse, the screen will change colors. 
 */

//Global Variables go here
var x =300
var y= 175

function setup() {
  // this function will run once
  createCanvas(600, 400); // create a 600x400 pixel drawing canvas

}



function draw() {
  // this function runs again and again (60x per second)
  //  background(200)//light gray background



  //add your drawing code here ...
  background(200)
 
  //center point: (300, 175)
  //subtract 300 from all x args
  // subtract 175 from all y args
  x++
  if(x > width){
    x = 0
  }
  push()
  translate(x, y);
  rect(-100, -145, 200, 300); //screen and functions
  if (mouseIsPressed) {
    fill(50, 90, 85)// screen color
    //check each frame to see if the mouse is pressed, then do something
  } else {
    fill(204, 266, 85)// screen color
    // do something here if the mouse is NOT pressed
  }
  rect(-90, -125, 180, 250);// screen 
  fill(0, 250, 10);// camera color
  ellipse(-10, -135, 10, 10); //camera
  fill(0, 250, 10)// speaker color
  rect(0, -137, 20, 5);//speaker
  fill(0, 250, 10)
  ellipse(-5, 140, 20, 20)//home button
  fill(0, 20, 150);// left eye color
  ellipse(-30, -35, 30, 30)// left eye
  fill(0, 20, 150) // right eye color
  strokeWeight(2);
  stroke(2)
  ellipse(30, -35, 30, 30)// right eye
  fill(0, 20, 150)// mouth, phone color
  rect(-18, 35, 40, 40)// mouth
  pop()
 
//glass cases and tables
  fill(100, 50, 12)
  rect(1, 330, 600, 600) // table
  fill(255) //glass case color left
  rect(10, 5, 80, 320) // glass case left
  rect(510, 5, 80, 320)// glass case right

  //left phones
  fill(200, 16, 12)//phone 1 color
  rect(15, 10, 18, 25)// phone 1
  fill(16, 221, 34)// phone 2 color
  rect(40, 10, 18, 25)// 2
  fill(24, 10, 90)//3 color
  rect(65, 10, 18, 25) //3
  fill(0) //4 color
  rect(15, 40, 18, 25) //4 phone
  fill(255, 10, 0)//5 color
  rect(40, 40, 18, 25) //5
  fill(60, 190, 12)//6
  rect(65, 40, 18, 25)//6
  fill(200, 135, 99)//7
  rect(15, 70, 18, 25)//7
  fill(100, 240, 220)//8
  rect(40, 70, 18, 25)//8
  fill(60, 90, 240)//9
  rect(65, 70, 18, 25)//9
  fill(240, 250, 0)//10
  rect(15, 100, 18, 25)//10
  fill(12, 100, 200)//11
  rect(40, 100, 18, 25)//11
  fill(66, 27, 93)//12
  rect(65, 100, 18, 25)//12
  fill(136, 241, 212)//13
  rect(15, 130, 18, 25)//13
  fill(24, 98, 202)//14
  rect(40, 130, 18, 25)//14
  fill(202, 98, 99)//15
  rect(40, 130, 18, 25)//15
  fill(137, 88, 12)//16
  rect(65, 130, 18, 25)//16
  fill(22, 99, 13)//17
  rect(15, 160, 18, 25)//17
  fill(205, 99, 187)//18
  rect(40, 160, 18, 25)//18
  fill(34, 192, 99)//19
  rect(65, 160, 18, 25)//19
  fill(91, 207, 158)//20
  rect(65, 160, 18, 25)//20
  fill(1, 2, 3)
  rect(15, 190, 18, 25)//21
  fill(219, 200, 69)
  rect(40, 190, 18, 25)
  fill(20, 20, 20)
  rect(65, 190, 18, 25)
  fill(70, 70, 70)
  rect(15, 220, 18, 25)
  fill(200, 200, 200)
  rect(40, 220, 18, 25)
  fill(30, 70, 190)
  rect(65, 220, 18, 25)
  fill(98, 210, 39)
  rect(15, 250, 18, 25)
  fill(87, 224, 198)
  rect(40, 250, 18, 25)
  fill(123, 10, 99)
  rect(65, 250, 18, 25)
  fill(12, 99, 100)
  rect(15, 280, 18, 25)
  fill(99, 200, 39)
  rect(40, 280, 18, 25)
  fill(197, 27, 27)
  rect(65, 280, 18, 25)

  //right phones
  fill(200, 16, 12)//phone 1 color
  rect(515, 10, 18, 25)// phone 1
  fill(16, 221, 34)// phone 2 color
  rect(540, 10, 18, 25)// 2
  fill(24, 10, 90)//3 color
  rect(565, 10, 18, 25) //3
  fill(0) //4 color
  rect(515, 40, 18, 25) //4 phone
  fill(255, 10, 0)//5 color
  rect(540, 40, 18, 25) //5
  fill(60, 190, 12)//6
  rect(565, 40, 18, 25)//6
  fill(200, 135, 99)//7
  rect(515, 70, 18, 25)//7
  fill(100, 240, 220)//8
  rect(540, 70, 18, 25)//8
  fill(60, 90, 240)//9
  rect(565, 70, 18, 25)//9
  fill(240, 250, 0)//10
  rect(515, 100, 18, 25)//10
  fill(12, 100, 200)//11
  rect(540, 100, 18, 25)//11
  fill(66, 27, 93)//12
  rect(565, 100, 18, 25)//12
  fill(136, 241, 212)//13
  rect(515, 130, 18, 25)//13
  fill(24, 98, 202)//14
  rect(540, 130, 18, 25)//14
  fill(202, 98, 99)//15
  rect(540, 130, 18, 25)//15
  fill(137, 88, 12)//16
  rect(565, 130, 18, 25)//16
  fill(22, 99, 13)//17
  rect(515, 160, 18, 25)//17
  fill(205, 99, 187)//18
  rect(540, 160, 18, 25)//18
  fill(34, 192, 99)//19
  rect(565, 160, 18, 25)//19
  fill(91, 207, 158)//20
  rect(65, 160, 18, 25)//20
  fill(1, 2, 3)//21
  rect(515, 190, 18, 25)//21
  fill(219, 200, 69)//22
  rect(540, 190, 18, 25)//22
  fill(20, 20, 20)//23
  rect(565, 190, 18, 25)//23
  fill(70, 70, 70)//24
  rect(515, 220, 18, 25)//24)
  fill(200, 200, 200)//25
  rect(540, 220, 18, 25)//25
  fill(30, 70, 190)//26
  rect(565, 220, 18, 25)//26
  fill(98, 210, 39)//27
  rect(515, 250, 18, 25)//27
  fill(87, 224, 198)//28
  rect(540, 250, 18, 25)//28
  fill(123, 10, 99)//29
  rect(565, 250, 18, 25)//29
  fill(12, 99, 100)//30
  rect(515, 280, 18, 25)//30
  fill(99, 200, 39)//31
  rect(540, 280, 18, 25)//31
  fill(197, 27, 27)//32
  rect(565, 280, 18, 25)//32

}

/* 
  Use the following if()...else() structure to incorporate mouse click control of your animation
*/


/** 
 * the mousePressed() function is separate from draw(). 
 * It only runs (one time) if the mouse is clicked
*/
function mousePressed() {
  // add code here that will execute once each time the mouse is pressed
}